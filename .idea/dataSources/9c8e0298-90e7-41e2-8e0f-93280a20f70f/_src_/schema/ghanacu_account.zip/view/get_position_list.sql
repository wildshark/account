CREATE VIEW get_position_list AS
  SELECT
    `ghanacu_account`.`position_list`.`positionID` AS `positionID`,
    `ghanacu_account`.`position_list`.`position`   AS `position`,
    `ghanacu_account`.`position_list`.`statusId`   AS `statusId`
  FROM `ghanacu_account`.`position_list`;
