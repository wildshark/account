CREATE VIEW get_fees_bill_summary AS
  SELECT
    `ghanacu_account`.`fees_payment`.`studentID`       AS `studentID`,
    `ghanacu_account`.`student_profile`.`studentName`  AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo`  AS `admissionNo`,
    `ghanacu_account`.`fees_payment`.`semesterID`      AS `semesterID`,
    `ghanacu_account`.`fees_payment`.`sch_session`     AS `sch_session`,
    `ghanacu_account`.`fees_payment`.`schoolID`        AS `schoolID`,
    `ghanacu_account`.`fees_payment`.`tutor_materials` AS `tutor_materials`,
    `ghanacu_account`.`fees_payment`.`hostel_fees`     AS `hostel_fees`,
    `ghanacu_account`.`fees_payment`.`discount`        AS `discount`,
    `ghanacu_account`.`fees_payment`.`previous_bal`    AS `previous_bal`,
    `ghanacu_account`.`fees_payment`.`fees_amount`     AS `amount`,
    `ghanacu_account`.`school`.`school`                AS `school`,
    `ghanacu_account`.`school`.`prefix`                AS `prefix`,
    `ghanacu_account`.`fees_payment`.`tranDate`        AS `tranDate`,
    `ghanacu_account`.`fees_payment`.`payDate`         AS `payDate`,
    `ghanacu_account`.`fees_payment`.`main_fees`       AS `main_fees`,
    `ghanacu_account`.`fees_payment`.`refNo`           AS `refNo`
  FROM ((`ghanacu_account`.`fees_payment`
    JOIN `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`fees_payment`.`studentID` = `ghanacu_account`.`student_profile`.`studentID`))) JOIN
    `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`fees_payment`.`schoolID` = `ghanacu_account`.`school`.`schoolID`)))
  GROUP BY `ghanacu_account`.`fees_payment`.`studentID`, `ghanacu_account`.`fees_payment`.`fees_amount`;
