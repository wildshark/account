CREATE VIEW get_fees_revenu_journal AS
  SELECT
    `ghanacu_account`.`fees_bill`.`yearID`            AS `yearID`,
    `ghanacu_account`.`fees_bill`.`semesterID`        AS `semesterID`,
    `ghanacu_account`.`fees_bill`.`revenueID`         AS `revenueID`,
    `ghanacu_account`.`fees_bill`.`amount`            AS `amount`,
    `ghanacu_account`.`fees_bill`.`transDate`         AS `transDate`,
    `ghanacu_account`.`fees_bill`.`jDate`             AS `jDate`,
    `ghanacu_account`.`fees_bill`.`studentID`         AS `studentID`,
    `ghanacu_account`.`revenue_list`.`revenue`        AS `revenue`,
    `ghanacu_account`.`student_profile`.`studentName` AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo` AS `admissionNo`
  FROM ((`ghanacu_account`.`fees_bill`
    JOIN `ghanacu_account`.`revenue_list`
      ON ((`ghanacu_account`.`fees_bill`.`revenueID` = `ghanacu_account`.`revenue_list`.`revenueID`))) JOIN
    `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`fees_bill`.`studentID` = `ghanacu_account`.`student_profile`.`studentID`)));
