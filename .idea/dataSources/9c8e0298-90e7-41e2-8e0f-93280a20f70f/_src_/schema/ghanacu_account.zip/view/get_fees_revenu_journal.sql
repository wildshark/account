CREATE VIEW get_fees_revenu_journal AS
  SELECT
    `ghanacu_account`.`fees_journal`.`yearID`         AS `yearID`,
    `ghanacu_account`.`fees_journal`.`semesterID`     AS `semesterID`,
    `ghanacu_account`.`fees_journal`.`revenueID`      AS `revenueID`,
    `ghanacu_account`.`fees_journal`.`amount`         AS `amount`,
    `ghanacu_account`.`fees_journal`.`fees_journalID` AS `fees_journalID`,
    `ghanacu_account`.`fees_journal`.`transDate`      AS `transDate`,
    `ghanacu_account`.`fees_journal`.`jDate`          AS `jDate`,
    `ghanacu_account`.`fees_journal`.`studentID`      AS `studentID`,
    `ghanacu_account`.`revenue_list`.`revenue`        AS `revenue`,
    `ghanacu_account`.`student_profile`.`studentName` AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo` AS `admissionNo`
  FROM ((`ghanacu_account`.`fees_journal`
    JOIN `ghanacu_account`.`revenue_list`
      ON ((`ghanacu_account`.`fees_journal`.`revenueID` = `ghanacu_account`.`revenue_list`.`revenueID`))) JOIN
    `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`fees_journal`.`studentID` = `ghanacu_account`.`student_profile`.`studentID`)));
