CREATE VIEW ious AS
  SELECT
    `get_ious`.`tranCatID`                        AS `tranCatID`,
    sum(`get_ious`.`cost`)                        AS `cost`,
    sum(`get_ious`.`paid`)                        AS `paid`,
    (`get_ious`.`cost` - `get_ious`.`paid`)       AS `bal`,
    `ghanacu_account`.`chart_of_account`.`ledger` AS `ledger`
  FROM (`ghanacu_account`.`get_ious`
    JOIN `ghanacu_account`.`chart_of_account`
      ON ((`ghanacu_account`.`chart_of_account`.`TranCatID` = `get_ious`.`tranCatID`)))
  GROUP BY `get_ious`.`tranCatID`;
