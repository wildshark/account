CREATE VIEW fees_details_summary AS
  SELECT
    `get_fees_revenu_journal`.`revenue`     AS `revenue`,
    sum(`get_fees_revenu_journal`.`amount`) AS `total`,
    `get_fees_revenu_journal`.`revenueID`   AS `revenueID`
  FROM `ghanacu_account`.`get_fees_revenu_journal`
  GROUP BY `get_fees_revenu_journal`.`revenue`
  ORDER BY `get_fees_revenu_journal`.`revenueID`;
