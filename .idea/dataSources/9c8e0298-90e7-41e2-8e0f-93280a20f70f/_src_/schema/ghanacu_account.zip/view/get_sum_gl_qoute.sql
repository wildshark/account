CREATE VIEW get_sum_gl_qoute AS
  SELECT
    count(`ghanacu_account`.`general_legder`.`GL_ID`) AS `gl_ID`,
    sum(`ghanacu_account`.`general_legder`.`qouteDr`) AS `qDr`,
    sum(`ghanacu_account`.`general_legder`.`qouteCr`) AS `qCr`
  FROM `ghanacu_account`.`general_legder`;
