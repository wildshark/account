CREATE VIEW get_staff_profile_list AS
  SELECT
    `ghanacu_account`.`staff_profile`.`staff_profile_ID` AS `staff_profile_ID`,
    `ghanacu_account`.`staff_profile`.`staffName`        AS `staffName`,
    `ghanacu_account`.`staff_profile`.`basicPay`         AS `basicPay`,
    `ghanacu_account`.`staff_profile`.`allowance`        AS `allowance`,
    `ghanacu_account`.`staff_profile`.`bankID`           AS `bankID`,
    `ghanacu_account`.`staff_profile`.`acctName`         AS `acctName`,
    `ghanacu_account`.`staff_profile`.`acctNumber`       AS `acctNumber`,
    `ghanacu_account`.`staff_profile`.`staffID`          AS `staffID`
  FROM `ghanacu_account`.`staff_profile`;
