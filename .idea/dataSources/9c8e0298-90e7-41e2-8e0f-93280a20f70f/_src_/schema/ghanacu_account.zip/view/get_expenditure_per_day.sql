CREATE VIEW get_expenditure_per_day AS
  SELECT
    `get_expenditure_book`.`GL_ID`                AS `GL_ID`,
    `get_expenditure_book`.`tranDate`             AS `tranDate`,
    `get_expenditure_book`.`GL_date`              AS `GL_date`,
    `get_expenditure_book`.`refNo`                AS `refNo`,
    `get_expenditure_book`.`qouteDr`              AS `qouteDr`,
    `get_expenditure_book`.`tranCatID`            AS `tranCatID`,
    `ghanacu_account`.`chart_of_account`.`ledger` AS `ledger`
  FROM (`ghanacu_account`.`get_expenditure_book`
    JOIN `ghanacu_account`.`chart_of_account`
      ON ((`get_expenditure_book`.`tranCatID` = `ghanacu_account`.`chart_of_account`.`TranCatID`)));
