CREATE VIEW get_payroll_tax AS
  SELECT
    `ghanacu_account`.`payroll`.`payDate`        AS `payDate`,
    `ghanacu_account`.`payroll`.`year`           AS `year`,
    `ghanacu_account`.`payroll`.`semester`       AS `semester`,
    sum(`ghanacu_account`.`payroll`.`GH216Free`) AS `total_GH216Free`,
    sum(`ghanacu_account`.`payroll`.`GH108`)     AS `total_GH108`,
    sum(`ghanacu_account`.`payroll`.`GH151`)     AS `total_GH151`,
    sum(`ghanacu_account`.`payroll`.`GH2765`)    AS `total_GH2765`
  FROM `ghanacu_account`.`payroll`
  GROUP BY `ghanacu_account`.`payroll`.`payDate`, `ghanacu_account`.`payroll`.`year`,
    `ghanacu_account`.`payroll`.`semester`;
