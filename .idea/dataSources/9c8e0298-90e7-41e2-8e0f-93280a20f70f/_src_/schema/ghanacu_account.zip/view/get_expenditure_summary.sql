CREATE VIEW get_expenditure_summary AS
  SELECT
    `get_expenditure_book`.`tranCatID`        AS `tranCatID`,
    `get_expenditure_book`.`bookID`           AS `bookID`,
    `get_expenditure_book`.`yearID`           AS `yearID`,
    count(`get_expenditure_book`.`tranCatID`) AS `NoOfTransaction`,
    sum(`get_expenditure_book`.`qouteDr`)     AS `Dr`,
    sum(`get_expenditure_book`.`qouteCr`)     AS `Cr`,
    `get_expenditure_book`.`semesterID`       AS `semesterID`,
    `get_expenditure_list`.`ledger`           AS `ledger`
  FROM (`ghanacu_account`.`get_expenditure_book`
    JOIN `ghanacu_account`.`get_expenditure_list`
      ON ((`get_expenditure_book`.`tranCatID` = `get_expenditure_list`.`TranCatID`)))
  GROUP BY `get_expenditure_book`.`tranCatID`, `get_expenditure_book`.`bookID`, `get_expenditure_book`.`yearID`,
    `get_expenditure_book`.`semesterID`, `get_expenditure_list`.`ledger`;
