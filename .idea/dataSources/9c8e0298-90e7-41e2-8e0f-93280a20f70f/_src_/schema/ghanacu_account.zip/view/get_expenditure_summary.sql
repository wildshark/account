CREATE VIEW get_expenditure_summary AS
  SELECT
    `get_expenditurebook`.`tranTypeID` AS `tranTypeID`,
    `get_expenditurebook`.`qouteDr`    AS `qouteDr`,
    `get_expenditurebook`.`qouteCr`    AS `qouteCr`,
    `get_expenditurebook`.`yearID`     AS `yearID`,
    `get_expenditurebook`.`semesterID` AS `semesterID`,
    `get_expenditurebook`.`bookID`     AS `bookID`,
    `get_expenditurebook`.`tranCatID`  AS `tranCatID`,
    `get_expenditure_list`.`ledger`    AS `ledger`
  FROM (`ghanacu_account`.`get_expenditurebook`
    JOIN `ghanacu_account`.`get_expenditure_list`
      ON ((`get_expenditurebook`.`tranCatID` = `get_expenditure_list`.`TranCatID`)))
  GROUP BY `get_expenditurebook`.`bookID`, `get_expenditurebook`.`tranCatID`, `get_expenditurebook`.`tranTypeID`;
