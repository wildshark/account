CREATE VIEW get_fees_balance AS
  SELECT
    `get_fees_paid`.`studentID`                                          AS `studentID`,
    sum(`get_fees_paid`.`fees_amount`)                                   AS `fees`,
    sum(`get_fees_paid`.`paid_amount`)                                   AS `paid`,
    sum((`get_fees_paid`.`fees_amount` - `get_fees_paid`.`paid_amount`)) AS `bal`
  FROM `ghanacu_account`.`get_fees_paid`
  GROUP BY `get_fees_paid`.`studentID`;
