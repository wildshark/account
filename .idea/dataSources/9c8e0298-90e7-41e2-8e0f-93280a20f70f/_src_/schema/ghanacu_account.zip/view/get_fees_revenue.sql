CREATE VIEW get_fees_revenue AS
  SELECT
    `ghanacu_account`.`fees_revenue`.`revenueID`      AS `revenueID`,
    `ghanacu_account`.`fees_revenue`.`tranDate`       AS `tranDate`,
    `ghanacu_account`.`fees_revenue`.`payDate`        AS `payDate`,
    `ghanacu_account`.`fees_revenue`.`studentID`      AS `studentID`,
    `ghanacu_account`.`fees_revenue`.`schoolID`       AS `schoolID`,
    `ghanacu_account`.`fees_revenue`.`payID`          AS `payID`,
    `ghanacu_account`.`fees_revenue`.`amount`         AS `amount`,
    `ghanacu_account`.`school`.`prefix`               AS `prefix`,
    `ghanacu_account`.`school`.`school`               AS `school`,
    `ghanacu_account`.`student_profile`.`studentName` AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo` AS `admissionNo`,
    `ghanacu_account`.`payment_type`.`type`           AS `type`
  FROM (((`ghanacu_account`.`fees_revenue`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`fees_revenue`.`schoolID` = `ghanacu_account`.`school`.`schoolID`))) JOIN
    `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`fees_revenue`.`studentID` = `ghanacu_account`.`student_profile`.`studentID`))) JOIN
    `ghanacu_account`.`payment_type`
      ON ((`ghanacu_account`.`fees_revenue`.`payID` = `ghanacu_account`.`payment_type`.`pay_TypeID`)));
