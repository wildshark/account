CREATE VIEW get_profile_loss AS
  SELECT
    `get_ledger`.`GL_ID`       AS `GL_ID`,
    `get_ledger`.`tranDate`    AS `tranDate`,
    `get_ledger`.`GL_date`     AS `GL_date`,
    `get_ledger`.`ticketID`    AS `ticketID`,
    `get_ledger`.`bookID`      AS `bookID`,
    `get_ledger`.`tranCatID`   AS `tranCatID`,
    `get_ledger`.`description` AS `description`,
    `get_ledger`.`refNo`       AS `refNo`,
    `get_ledger`.`qouteDr`     AS `qouteDr`,
    `get_ledger`.`qouteCr`     AS `qouteCr`,
    `get_ledger`.`tranTypeID`  AS `tranTypeID`,
    `get_ledger`.`yearID`      AS `yearID`,
    `get_ledger`.`semesterID`  AS `semesterID`
  FROM `ghanacu_account`.`get_ledger`;
