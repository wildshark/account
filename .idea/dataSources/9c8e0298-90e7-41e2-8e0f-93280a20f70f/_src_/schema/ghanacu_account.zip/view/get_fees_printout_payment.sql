CREATE VIEW get_fees_printout_payment AS
  SELECT
    `ghanacu_account`.`fees_payment`.`payID`          AS `payID`,
    `ghanacu_account`.`fees_payment`.`tranDate`       AS `tranDate`,
    `ghanacu_account`.`fees_payment`.`payDate`        AS `payDate`,
    `ghanacu_account`.`fees_payment`.`studentID`      AS `studentID`,
    `ghanacu_account`.`fees_payment`.`schoolID`       AS `schoolID`,
    `ghanacu_account`.`fees_payment`.`payTypeID`      AS `payTypeID`,
    `ghanacu_account`.`fees_payment`.`stud_level`     AS `stud_level`,
    `ghanacu_account`.`fees_payment`.`semesterID`     AS `semesterID`,
    `ghanacu_account`.`fees_payment`.`sch_session`    AS `sch_session`,
    `ghanacu_account`.`fees_payment`.`refNo`          AS `refNo`,
    `ghanacu_account`.`fees_payment`.`fees_amount`    AS `fees_amount`,
    `ghanacu_account`.`fees_payment`.`paid_amount`    AS `paid_amount`,
    `ghanacu_account`.`student_profile`.`studentName` AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo` AS `admissionNo`,
    `ghanacu_account`.`payment_type`.`type`           AS `type`,
    `ghanacu_account`.`semester_list`.`Semester`      AS `Semester`,
    `ghanacu_account`.`school`.`school`               AS `school`
  FROM ((((`ghanacu_account`.`fees_payment`
    JOIN `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`student_profile`.`studentID` = `ghanacu_account`.`fees_payment`.`studentID`))) JOIN
    `ghanacu_account`.`payment_type`
      ON ((`ghanacu_account`.`payment_type`.`pay_TypeID` = `ghanacu_account`.`fees_payment`.`payTypeID`))) JOIN
    `ghanacu_account`.`semester_list`
      ON ((`ghanacu_account`.`semester_list`.`semesterID` = `ghanacu_account`.`fees_payment`.`semesterID`))) JOIN
    `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`fees_payment`.`schoolID`)))
  ORDER BY `ghanacu_account`.`fees_payment`.`payID` DESC
  LIMIT 1;
