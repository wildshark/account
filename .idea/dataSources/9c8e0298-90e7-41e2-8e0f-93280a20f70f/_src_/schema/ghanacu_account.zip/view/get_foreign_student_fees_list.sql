CREATE VIEW get_foreign_student_fees_list AS
  SELECT
    `get_fees_list`.`feesID`                                                            AS `feesID`,
    `get_fees_list`.`schoolID`                                                          AS `schoolID`,
    `get_fees_list`.`tuition`                                                           AS `tuition`,
    `get_fees_list`.`matriculation`                                                     AS `matriculation`,
    `get_fees_list`.`accept_fees`                                                       AS `accept_fees`,
    `get_fees_list`.`medical_examin`                                                    AS `medical_examin`,
    `get_fees_list`.`result_fees`                                                       AS `result_fees`,
    `get_fees_list`.`lab_fees`                                                          AS `lab_fees`,
    `get_fees_list`.`indexing`                                                          AS `indexing`,
    `get_fees_list`.`nmc_book`                                                          AS `nmc_book`,
    `get_fees_list`.`clinical_fees`                                                     AS `clinical_fees`,
    `get_fees_list`.`technology`                                                        AS `technology`,
    `get_fees_list`.`hostel`                                                            AS `hostel`,
    `get_fees_list`.`wasce`                                                             AS `wasce`,
    `get_fees_list`.`other2`                                                            AS `other2`,
    `get_fees_list`.`other1`                                                            AS `other1`,
    `get_fees_list`.`statusID`                                                          AS `statusID`,
    `get_fees_list`.`school`                                                            AS `school`,
    `get_fees_list`.`prefix`                                                            AS `prefix`,
    (((((((((((`get_fees_list`.`matriculation` + `get_fees_list`.`accept_fees`) + `get_fees_list`.`medical_examin`) +
             `get_fees_list`.`result_fees`) + `get_fees_list`.`indexing`) + `get_fees_list`.`nmc_book`) +
          `get_fees_list`.`clinical_fees`) + `get_fees_list`.`technology`) + `get_fees_list`.`hostel`) +
       `get_fees_list`.`wasce`) + `get_fees_list`.`other2`) + `get_fees_list`.`other1`) AS `total_fees`
  FROM `ghanacu_account`.`get_fees_list`
  WHERE (`get_fees_list`.`statusID` = 2);
