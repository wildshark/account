CREATE VIEW get_summary_salary_control AS
  SELECT
    `get_salary_control`.`GL_date`                                         AS `GL_date`,
    sum(`get_salary_control`.`qouteDr`)                                    AS `Dr`,
    sum(`get_salary_control`.`qouteCr`)                                    AS `Cr`,
    sum((`get_salary_control`.`qouteDr` - `get_salary_control`.`qouteCr`)) AS `balance`
  FROM `ghanacu_account`.`get_salary_control`
  GROUP BY `get_salary_control`.`GL_date`;
