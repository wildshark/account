CREATE VIEW get_profit_loss_income AS
  SELECT
    `ghanacu_account`.`fees_payment`.`payDate`         AS `payDate`,
    `ghanacu_account`.`fees_payment`.`semesterID`      AS `semesterID`,
    `ghanacu_account`.`fees_payment`.`studentID`       AS `studentID`,
    `ghanacu_account`.`fees_payment`.`main_fees`       AS `main_fees`,
    `ghanacu_account`.`fees_payment`.`tutor_materials` AS `tutor_materials`
  FROM `ghanacu_account`.`fees_payment`;
