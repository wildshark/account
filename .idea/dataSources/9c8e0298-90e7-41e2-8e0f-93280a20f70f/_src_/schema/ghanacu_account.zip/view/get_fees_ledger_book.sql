CREATE VIEW get_fees_ledger_book AS
  SELECT
    `ghanacu_account`.`fees_payment`.`studentID`        AS `studentID`,
    `ghanacu_account`.`fees_payment`.`stud_level`       AS `stud_level`,
    `ghanacu_account`.`fees_payment`.`semesterID`       AS `semesterID`,
    `ghanacu_account`.`fees_payment`.`sch_session`      AS `sch_session`,
    `ghanacu_account`.`fees_payment`.`fees_amount`      AS `amount`,
    sum(`ghanacu_account`.`fees_payment`.`paid_amount`) AS `paid`,
    `ghanacu_account`.`student_profile`.`studentName`   AS `studentName`,
    `ghanacu_account`.`student_profile`.`AdmissionNo`   AS `AdmissionNo`
  FROM (`ghanacu_account`.`fees_payment`
    JOIN `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`fees_payment`.`studentID` = `ghanacu_account`.`student_profile`.`studentID`)))
  GROUP BY `ghanacu_account`.`fees_payment`.`studentID`, `ghanacu_account`.`fees_payment`.`stud_level`,
    `ghanacu_account`.`fees_payment`.`semesterID`, `ghanacu_account`.`fees_payment`.`sch_session`,
    `ghanacu_account`.`fees_payment`.`fees_amount`;
