CREATE VIEW get_fees_ledger_book AS
  SELECT
    `ghanacu_account`.`fees_payment`.`studentID`                                                      AS `studentID`,
    `ghanacu_account`.`student_profile`.`studentName`                                                 AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo`                                                 AS `admissionNo`,
    `ghanacu_account`.`fees_payment`.`semesterID`                                                     AS `semesterID`,
    `ghanacu_account`.`fees_payment`.`sch_session`                                                    AS `sch_session`,
    `ghanacu_account`.`fees_payment`.`schoolID`                                                       AS `schoolID`,
    (`ghanacu_account`.`fees_payment`.`fees_amount` + `ghanacu_account`.`fees_payment`.`hostel_fees`) AS `amount`,
    sum(`ghanacu_account`.`fees_payment`.`paid_amount`)                                               AS `paid`
  FROM (`ghanacu_account`.`fees_payment`
    JOIN `ghanacu_account`.`student_profile`
      ON ((`ghanacu_account`.`fees_payment`.`studentID` = `ghanacu_account`.`student_profile`.`studentID`)))
  GROUP BY `ghanacu_account`.`fees_payment`.`studentID`, `ghanacu_account`.`fees_payment`.`fees_amount`;
