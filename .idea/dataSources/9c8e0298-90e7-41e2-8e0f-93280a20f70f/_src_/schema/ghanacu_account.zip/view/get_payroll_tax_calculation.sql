CREATE VIEW get_payroll_tax_calculation AS
  SELECT
    `get_payroll_tax`.`payDate`        AS `payDate`,
    `get_payroll_tax`.`year`           AS `year`,
    `get_payroll_tax`.`semester`       AS `semester`,
    (((`get_payroll_tax`.`total_GH216Free` + `get_payroll_tax`.`total_GH108`) + `get_payroll_tax`.`total_GH151`) +
     `get_payroll_tax`.`total_GH2765`) AS `payroll_tax_amount`
  FROM `ghanacu_account`.`get_payroll_tax`;
