CREATE VIEW get_count_course_for_sch AS
  SELECT
    count(`ghanacu_account`.`course`.`schoolID`) AS `NoOfCourse`,
    `ghanacu_account`.`school`.`school`          AS `school`,
    `ghanacu_account`.`school`.`prefix`          AS `prefix`
  FROM (`ghanacu_account`.`course`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`course`.`schoolID`)))
  GROUP BY `ghanacu_account`.`course`.`statusID`, `ghanacu_account`.`school`.`school`,
    `ghanacu_account`.`school`.`prefix`;
