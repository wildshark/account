CREATE VIEW get_payment_voucher_summary AS
  SELECT
    `get_payment_voucher`.`bookID`      AS `bookID`,
    `get_payment_voucher`.`tranCatID`   AS `tranCatID`,
    `get_payment_voucher`.`semesterID`  AS `semesterID`,
    `get_payment_voucher`.`yearID`      AS `yearID`,
    sum(`get_payment_voucher`.`cashCr`) AS `cash`,
    sum(`get_payment_voucher`.`bankCr`) AS `bank`,
    sum(`get_payment_voucher`.`amount`) AS `amount`,
    `get_expenditure_list`.`ledger`     AS `ledger`
  FROM (`ghanacu_account`.`get_payment_voucher`
    JOIN `ghanacu_account`.`get_expenditure_list`
      ON ((`get_payment_voucher`.`tranCatID` = `get_expenditure_list`.`TranCatID`)))
  GROUP BY `get_payment_voucher`.`bookID`, `get_payment_voucher`.`tranCatID`, `get_payment_voucher`.`semesterID`,
    `get_payment_voucher`.`yearID`, `get_expenditure_list`.`ledger`;
