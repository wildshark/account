CREATE VIEW get_student_list AS
  SELECT
    `ghanacu_account`.`student_profile`.`studentID`     AS `studentID`,
    `ghanacu_account`.`student_profile`.`admissionDate` AS `admissionDate`,
    `ghanacu_account`.`student_profile`.`studentName`   AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo`   AS `admissionNo`,
    `ghanacu_account`.`student_profile`.`mobile`        AS `mobile`,
    `ghanacu_account`.`student_profile`.`courseID`      AS `courseID`,
    `ghanacu_account`.`student_profile`.`admissionYr`   AS `admissionYr`,
    `ghanacu_account`.`student_profile`.`categoryID`    AS `categoryID`,
    `ghanacu_account`.`student_profile`.`statusID`      AS `statusID`,
    `ghanacu_account`.`student_profile`.`semester`      AS `semester`,
    `ghanacu_account`.`course`.`course`                 AS `course`,
    `ghanacu_account`.`course`.`schoolID`               AS `schoolID`,
    `ghanacu_account`.`school`.`prefix`                 AS `prefix`
  FROM ((`ghanacu_account`.`student_profile`
    JOIN `ghanacu_account`.`course`
      ON ((`ghanacu_account`.`student_profile`.`courseID` = `ghanacu_account`.`course`.`courseID`))) JOIN
    `ghanacu_account`.`school` ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`course`.`schoolID`)))
  WHERE (`ghanacu_account`.`student_profile`.`statusID` = 1);
