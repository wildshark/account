CREATE VIEW get_payroll AS
  SELECT
    `ghanacu_account`.`payroll`.`payrollID`                                   AS `payrollID`,
    `ghanacu_account`.`payroll`.`year`                                        AS `year`,
    `ghanacu_account`.`payroll`.`semester`                                    AS `semester`,
    `ghanacu_account`.`payroll`.`payDate`                                     AS `payDate`,
    `ghanacu_account`.`payroll`.`staffID`                                     AS `staffID`,
    `ghanacu_account`.`payroll`.`basic`                                       AS `basic`,
    `ghanacu_account`.`payroll`.`ssf`                                         AS `ssf`,
    (`ghanacu_account`.`payroll`.`basic` - `ghanacu_account`.`payroll`.`ssf`) AS `Sub_Total`,
    `ghanacu_account`.`payroll`.`allowance`                                   AS `allowance`,
    `ghanacu_account`.`payroll`.`GH216Free`                                   AS `GH216Free`,
    `ghanacu_account`.`payroll`.`GH108`                                       AS `GH108`,
    `ghanacu_account`.`payroll`.`GH151`                                       AS `GH151`,
    `ghanacu_account`.`payroll`.`GH2765`                                      AS `GH2765`,
    ((`ghanacu_account`.`payroll`.`basic` - `ghanacu_account`.`payroll`.`ssf`) +
     `ghanacu_account`.`payroll`.`allowance`)                                 AS `Taxable_salary`,
    ((`ghanacu_account`.`payroll`.`GH108` + `ghanacu_account`.`payroll`.`GH151`) +
     `ghanacu_account`.`payroll`.`GH2765`)                                    AS `Totalpaye`,
    (((`ghanacu_account`.`payroll`.`basic` - `ghanacu_account`.`payroll`.`ssf`) +
      `ghanacu_account`.`payroll`.`allowance`) -
     ((`ghanacu_account`.`payroll`.`GH108` + `ghanacu_account`.`payroll`.`GH151`) +
      `ghanacu_account`.`payroll`.`GH2765`))                                  AS `net_salary`,
    `ghanacu_account`.`payroll`.`salary`                                      AS `salary`,
    `ghanacu_account`.`payroll`.`bankID`                                      AS `bankID`,
    `ghanacu_account`.`payroll`.`acctName`                                    AS `acctName`,
    `ghanacu_account`.`payroll`.`AcctNo`                                      AS `AcctNo`
  FROM `ghanacu_account`.`payroll`;
