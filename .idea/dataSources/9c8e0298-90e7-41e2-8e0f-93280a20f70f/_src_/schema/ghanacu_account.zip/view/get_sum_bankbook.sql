CREATE VIEW get_sum_bankbook AS
  SELECT
    sum(`get_bankbook`.`bankDr`)  AS `Debit`,
    sum(`get_bankbook`.`bankCr`)  AS `Credit`,
    count(`get_bankbook`.`GL_ID`) AS `NoTran`
  FROM `ghanacu_account`.`get_bankbook`;
