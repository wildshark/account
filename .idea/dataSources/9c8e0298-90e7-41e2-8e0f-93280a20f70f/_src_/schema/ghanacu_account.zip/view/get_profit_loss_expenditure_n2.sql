CREATE VIEW get_profit_loss_expenditure_n2 AS
  SELECT
    `get_profit_loss_expenditure_n`.`GL_date`      AS `GL_date`,
    `get_profit_loss_expenditure_n`.`bookID`       AS `bookID`,
    `get_profit_loss_expenditure_n`.`tranCatID`    AS `tranCatID`,
    sum(`get_profit_loss_expenditure_n`.`qouteDr`) AS `dr`,
    sum(`get_profit_loss_expenditure_n`.`qouteCr`) AS `cr`,
    `global`.`ledger`                              AS `ledger`
  FROM (`ghanacu_account`.`get_profit_loss_expenditure_n`
    JOIN `ghanacu_account`.`global` ON ((`get_profit_loss_expenditure_n`.`tranCatID` = `global`.`TranCatID`)))
  WHERE ((`get_profit_loss_expenditure_n`.`qouteDr` <> 0) AND (`get_profit_loss_expenditure_n`.`bookID` <> 7) AND
         (`get_profit_loss_expenditure_n`.`profitlossID` <> 3))
  GROUP BY `get_profit_loss_expenditure_n`.`GL_date`, `get_profit_loss_expenditure_n`.`bookID`,
    `get_profit_loss_expenditure_n`.`tranCatID`;
