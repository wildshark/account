CREATE VIEW expenses_list_ AS
  SELECT
    `get_expenses_list`.`TranCatID`      AS `TranCatID`,
    `get_expenses_list`.`ledger`         AS `ledger`,
    `get_expenses_list`.`bookID`         AS `bookID`,
    `get_expenses_list`.`profitLossID`   AS `profitLossID`,
    `get_expenses_list`.`balanceSheetID` AS `balanceSheetID`,
    `get_expenses_list`.`statusID`       AS `statusID`
  FROM `ghanacu_account`.`get_expenses_list`
  WHERE ((`get_expenses_list`.`TranCatID` <> 39) AND (`get_expenses_list`.`TranCatID` <> 41) AND
         (`get_expenses_list`.`TranCatID` <> 34));
