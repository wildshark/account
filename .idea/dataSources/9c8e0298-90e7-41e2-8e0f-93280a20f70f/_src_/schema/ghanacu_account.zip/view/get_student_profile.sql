CREATE VIEW get_student_profile AS
  SELECT
    `ghanacu_account`.`student_profile`.`studentID`     AS `studentID`,
    `ghanacu_account`.`student_profile`.`studentName`   AS `studentName`,
    `ghanacu_account`.`student_profile`.`AdmissionNo`   AS `AdmissionNo`,
    `ghanacu_account`.`student_profile`.`Mobile`        AS `Mobile`,
    `ghanacu_account`.`student_profile`.`schoolID`      AS `schoolID`,
    `ghanacu_account`.`student_profile`.`couresID`      AS `couresID`,
    `ghanacu_account`.`student_profile`.`admissionYear` AS `admissionYear`,
    `ghanacu_account`.`student_profile`.`statusID`      AS `statusID`,
    `ghanacu_account`.`school`.`school`                 AS `school`,
    `ghanacu_account`.`course`.`course`                 AS `course`
  FROM ((`ghanacu_account`.`student_profile`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`student_profile`.`schoolID` = `ghanacu_account`.`school`.`schoolID`))) JOIN
    `ghanacu_account`.`course`
      ON ((`ghanacu_account`.`student_profile`.`couresID` = `ghanacu_account`.`course`.`courseID`)));
