CREATE VIEW get_student_profile AS
  SELECT
    `ghanacu_account`.`student_profile`.`studentID`   AS `studentID`,
    `ghanacu_account`.`student_profile`.`studentName` AS `studentName`,
    `ghanacu_account`.`student_profile`.`AdmissionNo` AS `AdmissionNo`,
    `ghanacu_account`.`student_profile`.`Mobile`      AS `Mobile`,
    `ghanacu_account`.`student_profile`.`schoolID`    AS `schoolID`,
    `ghanacu_account`.`student_profile`.`couresID`    AS `couresID`
  FROM `ghanacu_account`.`student_profile`;
