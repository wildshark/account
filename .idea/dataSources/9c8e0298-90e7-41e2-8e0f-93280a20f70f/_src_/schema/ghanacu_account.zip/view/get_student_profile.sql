CREATE VIEW get_student_profile AS
  SELECT
    `ghanacu_account`.`student_profile`.`studentID`     AS `studentID`,
    `ghanacu_account`.`student_profile`.`admissionDate` AS `admissionDate`,
    `ghanacu_account`.`student_profile`.`studentName`   AS `studentName`,
    `ghanacu_account`.`student_profile`.`admissionNo`   AS `admissionNo`,
    `ghanacu_account`.`student_profile`.`mobile`        AS `mobile`,
    `ghanacu_account`.`student_profile`.`courseID`      AS `courseID`,
    `ghanacu_account`.`student_profile`.`admissionYr`   AS `admissionYr`,
    `ghanacu_account`.`student_profile`.`categoryID`    AS `categoryID`,
    `ghanacu_account`.`student_profile`.`statusID`      AS `statusID`,
    `ghanacu_account`.`student_profile`.`semester`      AS `semester`,
    `ghanacu_account`.`student_profile`.`email`         AS `email`
  FROM `ghanacu_account`.`student_profile`;
