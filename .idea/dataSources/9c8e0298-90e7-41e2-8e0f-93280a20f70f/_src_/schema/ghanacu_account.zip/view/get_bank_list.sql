CREATE VIEW get_bank_list AS
  SELECT
    `ghanacu_account`.`bank_list`.`bankID`   AS `bankID`,
    `ghanacu_account`.`bank_list`.`bank`     AS `bank`,
    `ghanacu_account`.`bank_list`.`swift`    AS `swift`,
    `ghanacu_account`.`bank_list`.`statusID` AS `statusID`
  FROM `ghanacu_account`.`bank_list`
  WHERE (`ghanacu_account`.`bank_list`.`statusID` = 2);
