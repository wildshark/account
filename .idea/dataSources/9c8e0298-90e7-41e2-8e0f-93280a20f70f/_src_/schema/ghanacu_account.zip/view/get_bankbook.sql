CREATE VIEW get_bankbook AS
  SELECT
    `ghanacu_account`.`general_legder`.`GL_ID`           AS `GL_ID`,
    `ghanacu_account`.`general_legder`.`tranDate`        AS `tranDate`,
    `ghanacu_account`.`general_legder`.`GL_date`         AS `GL_date`,
    `ghanacu_account`.`general_legder`.`bookID`          AS `bookID`,
    `ghanacu_account`.`general_legder`.`tranCatID`       AS `tranCatID`,
    `ghanacu_account`.`general_legder`.`description`     AS `description`,
    `ghanacu_account`.`general_legder`.`refNo`           AS `refNo`,
    `ghanacu_account`.`general_legder`.`tranTypeID`      AS `tranTypeID`,
    `ghanacu_account`.`general_legder`.`yearID`          AS `yearID`,
    `ghanacu_account`.`general_legder`.`semesterID`      AS `semesterID`,
    `ghanacu_account`.`general_legder`.`staffID`         AS `staffID`,
    `ghanacu_account`.`general_legder`.`profitlossID`    AS `profitlossID`,
    `ghanacu_account`.`general_legder`.`balanceSheetID`  AS `balanceSheetID`,
    `ghanacu_account`.`general_legder`.`salaryControlID` AS `salaryControlID`,
    `ghanacu_account`.`general_legder`.`supplerID`       AS `supplerID`,
    `ghanacu_account`.`general_legder`.`userID`          AS `userID`
  FROM `ghanacu_account`.`general_legder`
  WHERE (`ghanacu_account`.`general_legder`.`tranTypeID` = 2);
