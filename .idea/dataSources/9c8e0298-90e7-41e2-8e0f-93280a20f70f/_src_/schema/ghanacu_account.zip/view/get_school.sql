CREATE VIEW get_school AS
  SELECT
    `ghanacu_account`.`school`.`schoolID` AS `schoolID`,
    `ghanacu_account`.`school`.`school`   AS `school`,
    `ghanacu_account`.`school`.`prefix`   AS `prefix`
  FROM `ghanacu_account`.`school`;
