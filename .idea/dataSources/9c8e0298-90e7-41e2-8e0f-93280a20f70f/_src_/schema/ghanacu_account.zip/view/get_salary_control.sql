CREATE VIEW get_salary_control AS
  SELECT
    sum(`get_payroll`.`Taxable_salary`) AS `TaxableSalary`,
    sum(`get_payroll`.`Totalpaye`)      AS `TotalPaye`,
    sum(`get_payroll`.`net_salary`)     AS `NetSalary`,
    `get_payroll`.`year`                AS `year`,
    `get_payroll`.`semester`            AS `semester`,
    `get_payroll`.`payDate`             AS `payDate`
  FROM `ghanacu_account`.`get_payroll`
  GROUP BY `get_payroll`.`year`, `get_payroll`.`semester`, `get_payroll`.`payDate`;
