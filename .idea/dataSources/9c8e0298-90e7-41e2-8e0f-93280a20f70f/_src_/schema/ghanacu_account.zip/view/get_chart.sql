CREATE VIEW get_chart AS
  SELECT
    `ghanacu_account`.`general_legder`.`GL_ID`                                                         AS `GL_ID`,
    sum(((`ghanacu_account`.`general_legder`.`cashDr` - `ghanacu_account`.`general_legder`.`cashCr`) +
         (`ghanacu_account`.`general_legder`.`bankDr` - `ghanacu_account`.`general_legder`.`bankCr`))) AS `outcash`
  FROM `ghanacu_account`.`general_legder`
  GROUP BY `ghanacu_account`.`general_legder`.`GL_ID`;
