CREATE VIEW get_general_ledger_summary AS
  SELECT
    `ghanacu_account`.`general_legder`.`bookID`                                                        AS `bookID`,
    `ghanacu_account`.`general_legder`.`tranCatID`                                                     AS `tranCatID`,
    sum(`ghanacu_account`.`general_legder`.`qouteDr`)                                                  AS `cost`,
    sum(`ghanacu_account`.`general_legder`.`qouteCr`)                                                  AS `paid`,
    sum((`ghanacu_account`.`general_legder`.`qouteCr` - `ghanacu_account`.`general_legder`.`qouteDr`)) AS `bal`,
    `ghanacu_account`.`chart_of_account`.`ledger`                                                      AS `ledger`,
    count(`ghanacu_account`.`general_legder`.`GL_ID`)                                                  AS `NoOfID`
  FROM (`ghanacu_account`.`general_legder`
    JOIN `ghanacu_account`.`chart_of_account`
      ON ((`ghanacu_account`.`general_legder`.`tranCatID` = `ghanacu_account`.`chart_of_account`.`TranCatID`)))
  WHERE (`ghanacu_account`.`general_legder`.`tranCatID` > 1)
  GROUP BY `ghanacu_account`.`general_legder`.`bookID`, `ghanacu_account`.`general_legder`.`tranCatID`,
    `ghanacu_account`.`chart_of_account`.`ledger`;
