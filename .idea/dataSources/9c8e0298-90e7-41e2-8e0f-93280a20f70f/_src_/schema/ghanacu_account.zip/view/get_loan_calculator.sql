CREATE VIEW get_loan_calculator AS
  SELECT
    `ghanacu_account`.`staff_loan`.`staff_loan_ID`                                  AS `staff_loan_ID`,
    `ghanacu_account`.`staff_loan`.`tranDate`                                       AS `tranDate`,
    `ghanacu_account`.`staff_loan`.`loanDate`                                       AS `loanDate`,
    `ghanacu_account`.`staff_loan`.`staffID`                                        AS `staffID`,
    `ghanacu_account`.`staff_loan`.`detail`                                         AS `detail`,
    `ghanacu_account`.`staff_loan`.`pay_amount`                                     AS `pay_amount`,
    `ghanacu_account`.`staff_loan`.`loan`                                           AS `loan`,
    `ghanacu_account`.`staff_loan`.`statusID`                                       AS `statusID`,
    `ghanacu_account`.`staff_loan`.`paid`                                           AS `paid`,
    ((`ghanacu_account`.`staff_loan`.`loan` - `ghanacu_account`.`staff_loan`.`paid`) /
     `ghanacu_account`.`staff_loan`.`pay_amount`)                                   AS `nMonth`,
    (`ghanacu_account`.`staff_loan`.`loan` - `ghanacu_account`.`staff_loan`.`paid`) AS `loan_bal`,
    `ghanacu_account`.`staff_profile`.`staffName`                                   AS `staffName`
  FROM (`ghanacu_account`.`staff_loan`
    JOIN `ghanacu_account`.`staff_profile`
      ON ((`ghanacu_account`.`staff_profile`.`staff_profile_ID` = `ghanacu_account`.`staff_loan`.`staffID`)));
