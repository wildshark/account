CREATE VIEW get_loan_calculator AS
  SELECT
    `ghanacu_account`.`staff_loan`.`staff_loan_ID`                       AS `staff_loan_ID`,
    `ghanacu_account`.`staff_loan`.`tranDate`                            AS `tranDate`,
    `ghanacu_account`.`staff_loan`.`loanDate`                            AS `loanDate`,
    `ghanacu_account`.`staff_loan`.`staffID`                             AS `staffID`,
    `ghanacu_account`.`staff_loan`.`detail`                              AS `detail`,
    `ghanacu_account`.`staff_loan`.`pay_amount`                          AS `pay_amount`,
    `ghanacu_account`.`staff_loan`.`loan`                                AS `loan`,
    `ghanacu_account`.`staff_loan`.`statusID`                            AS `statusID`,
    `get_loan_detail`.`amount`                                           AS `amount`,
    (`ghanacu_account`.`staff_loan`.`loan` - `get_loan_detail`.`amount`) AS `loan_bal`
  FROM (`ghanacu_account`.`staff_loan`
    JOIN `ghanacu_account`.`get_loan_detail`
      ON ((`get_loan_detail`.`staffID` = `ghanacu_account`.`staff_loan`.`staffID`)));
