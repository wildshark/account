CREATE VIEW get_expenses_payment_list AS
  SELECT
    `ghanacu_account`.`general_legder`.`tranCatID`                                                AS `tranCatID`,
    sum(`ghanacu_account`.`general_legder`.`qouteDr`)                                             AS `Qoute`,
    sum(`ghanacu_account`.`general_legder`.`qouteCr`)                                             AS `Paid`,
    (`ghanacu_account`.`general_legder`.`qouteDr` - `ghanacu_account`.`general_legder`.`qouteCr`) AS `bal`
  FROM `ghanacu_account`.`general_legder`
  GROUP BY `ghanacu_account`.`general_legder`.`tranCatID`;
