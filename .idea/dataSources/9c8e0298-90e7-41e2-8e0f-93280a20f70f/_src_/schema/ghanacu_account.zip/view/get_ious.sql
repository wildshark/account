CREATE VIEW get_ious AS
  SELECT
    `ghanacu_account`.`general_legder`.`GL_ID`                                                  AS `GL_ID`,
    `ghanacu_account`.`general_legder`.`tranDate`                                               AS `tranDate`,
    `ghanacu_account`.`general_legder`.`GL_date`                                                AS `GL_date`,
    `ghanacu_account`.`general_legder`.`ticketID`                                               AS `ticketID`,
    `ghanacu_account`.`general_legder`.`bookID`                                                 AS `bookID`,
    `ghanacu_account`.`general_legder`.`tranCatID`                                              AS `tranCatID`,
    `ghanacu_account`.`general_legder`.`description`                                            AS `description`,
    `ghanacu_account`.`general_legder`.`refNo`                                                  AS `refNo`,
    `ghanacu_account`.`general_legder`.`qouteDr`                                                AS `cost`,
    `ghanacu_account`.`general_legder`.`qouteCr`                                                AS `qouteCr`,
    `ghanacu_account`.`general_legder`.`cashCr`                                                 AS `cashCr`,
    `ghanacu_account`.`general_legder`.`bankCr`                                                 AS `bankCr`,
    (`ghanacu_account`.`general_legder`.`cashCr` + `ghanacu_account`.`general_legder`.`bankCr`) AS `paid`,
    `ghanacu_account`.`general_legder`.`yearID`                                                 AS `yearID`,
    `ghanacu_account`.`general_legder`.`semesterID`                                             AS `semesterID`
  FROM `ghanacu_account`.`general_legder`;
