CREATE VIEW get_ledger_calculator AS
  SELECT
    `ghanacu_account`.`general_legder`.`tranCatID`                                                     AS `tranCatID`,
    sum(`ghanacu_account`.`general_legder`.`qouteDr`)                                                  AS `Dr`,
    sum(`ghanacu_account`.`general_legder`.`qouteCr`)                                                  AS `Cr`,
    sum((`ghanacu_account`.`general_legder`.`qouteCr` - `ghanacu_account`.`general_legder`.`qouteDr`)) AS `balance`
  FROM `ghanacu_account`.`general_legder`
  GROUP BY `ghanacu_account`.`general_legder`.`tranCatID`;
