CREATE VIEW get_fees_price_list AS
  SELECT
    `ghanacu_account`.`fees_price_list`.`feesID` AS `feesID`,
    `ghanacu_account`.`school`.`school`          AS `school`,
    `ghanacu_account`.`course`.`course`          AS `course`,
    `ghanacu_account`.`fees_price_list`.`amount` AS `amount`
  FROM ((`ghanacu_account`.`fees_price_list`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`fees_price_list`.`schoolID`))) JOIN
    `ghanacu_account`.`course`
      ON ((`ghanacu_account`.`course`.`courseID` = `ghanacu_account`.`fees_price_list`.`courseID`)));
