CREATE VIEW get_key AS
  SELECT
    `ghanacu_account`.`key`.`keyID`       AS `keyID`,
    `ghanacu_account`.`key`.`year_id`     AS `year_id`,
    `ghanacu_account`.`key`.`semester_id` AS `semester_id`
  FROM `ghanacu_account`.`key`
  ORDER BY `ghanacu_account`.`key`.`keyID`
  LIMIT 1, 1;
