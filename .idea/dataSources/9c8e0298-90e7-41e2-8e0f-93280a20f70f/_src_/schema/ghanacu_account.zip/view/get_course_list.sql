CREATE VIEW get_course_list AS
  SELECT
    `ghanacu_account`.`course`.`courseID` AS `courseID`,
    `ghanacu_account`.`course`.`schoolID` AS `schoolID`,
    `ghanacu_account`.`course`.`course`   AS `course`,
    `ghanacu_account`.`course`.`statusID` AS `statusID`,
    `ghanacu_account`.`school`.`school`   AS `school`,
    `ghanacu_account`.`school`.`prefix`   AS `prefix`
  FROM (`ghanacu_account`.`course`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`course`.`schoolID`)))
  ORDER BY `ghanacu_account`.`course`.`courseID` DESC;
