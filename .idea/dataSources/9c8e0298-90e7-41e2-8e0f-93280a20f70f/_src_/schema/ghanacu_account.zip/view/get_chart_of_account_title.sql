CREATE VIEW get_chart_of_account_title AS
  SELECT
    `ghanacu_account`.`chart_of_account`.`TranCatID` AS `TranCatID`,
    `ghanacu_account`.`account_book`.`book`          AS `ACCT_book`,
    `ghanacu_account`.`profit_loss_book`.`types`     AS `PL_book`,
    `ghanacu_account`.`balance_sheet_book`.`type`    AS `BS_book`,
    `ghanacu_account`.`chart_of_account`.`ledger`    AS `ledger`
  FROM (((`ghanacu_account`.`chart_of_account`
    JOIN `ghanacu_account`.`account_book`
      ON ((`ghanacu_account`.`chart_of_account`.`bookID` = `ghanacu_account`.`account_book`.`bookID`))) JOIN
    `ghanacu_account`.`profit_loss_book` ON ((`ghanacu_account`.`chart_of_account`.`profitLossID` =
                                              `ghanacu_account`.`profit_loss_book`.`profitLossID`))) JOIN
    `ghanacu_account`.`balance_sheet_book` ON ((`ghanacu_account`.`chart_of_account`.`balanceSheetID` =
                                                `ghanacu_account`.`balance_sheet_book`.`balancesheetID`)))
  ORDER BY `ghanacu_account`.`chart_of_account`.`TranCatID`;
