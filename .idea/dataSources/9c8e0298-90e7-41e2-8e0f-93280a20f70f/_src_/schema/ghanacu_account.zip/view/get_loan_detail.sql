CREATE VIEW get_loan_detail AS
  SELECT
    `ghanacu_account`.`loan_details`.`staff_loan_ID` AS `staff_loan_ID`,
    `ghanacu_account`.`loan_details`.`staffID`       AS `staffID`,
    sum(`ghanacu_account`.`loan_details`.`amount`)   AS `amount`
  FROM `ghanacu_account`.`loan_details`
  GROUP BY `ghanacu_account`.`loan_details`.`staff_loan_ID`, `ghanacu_account`.`loan_details`.`staffID`;
