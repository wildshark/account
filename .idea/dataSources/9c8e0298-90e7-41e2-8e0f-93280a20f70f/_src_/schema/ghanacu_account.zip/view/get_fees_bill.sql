CREATE VIEW get_fees_bill AS
  SELECT
    `ghanacu_account`.`fees_bill`.`jDate`       AS `jDate`,
    `ghanacu_account`.`fees_bill`.`yearID`      AS `yearID`,
    `ghanacu_account`.`fees_bill`.`semesterID`  AS `semesterID`,
    `ghanacu_account`.`fees_bill`.`studentID`   AS `studentID`,
    `ghanacu_account`.`fees_bill`.`revenueID`   AS `revenueID`,
    sum(`ghanacu_account`.`fees_bill`.`amount`) AS `bill_amount`
  FROM `ghanacu_account`.`fees_bill`
  GROUP BY `ghanacu_account`.`fees_bill`.`jDate`, `ghanacu_account`.`fees_bill`.`yearID`,
    `ghanacu_account`.`fees_bill`.`revenueID`, `ghanacu_account`.`fees_bill`.`semesterID`,
    `ghanacu_account`.`fees_bill`.`studentID`;
