CREATE VIEW get_bank_chart AS
  SELECT
    `ghanacu_account`.`general_legder`.`GL_date` AS `GL_date`,
    `ghanacu_account`.`general_legder`.`bankDr`  AS `bankDr`,
    `ghanacu_account`.`general_legder`.`bankCr`  AS `bankCr`
  FROM `ghanacu_account`.`general_legder`
  GROUP BY `ghanacu_account`.`general_legder`.`GL_date`;
