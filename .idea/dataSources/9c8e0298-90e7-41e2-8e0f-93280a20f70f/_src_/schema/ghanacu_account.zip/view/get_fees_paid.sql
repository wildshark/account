CREATE VIEW get_fees_paid AS
  SELECT
    `ghanacu_account`.`fees_payment`.`studentID`        AS `studentID`,
    `ghanacu_account`.`fees_payment`.`fees_amount`      AS `fees`,
    sum(`ghanacu_account`.`fees_payment`.`paid_amount`) AS `Paid`,
    `ghanacu_account`.`fees_payment`.`semesterID`       AS `semesterID`,
    `ghanacu_account`.`fees_payment`.`sch_session`      AS `sch_session`,
    `ghanacu_account`.`fees_payment`.`stud_level`       AS `stud_level`
  FROM `ghanacu_account`.`fees_payment`
  GROUP BY `ghanacu_account`.`fees_payment`.`fees_amount`, `ghanacu_account`.`fees_payment`.`studentID`;
