CREATE VIEW get_profit_loss_expenditure_n AS
  SELECT
    `get_profit_loss_expenditure`.`GL_date`      AS `GL_date`,
    `get_profit_loss_expenditure`.`bookID`       AS `bookID`,
    `get_profit_loss_expenditure`.`tranCatID`    AS `tranCatID`,
    sum(`get_profit_loss_expenditure`.`qouteDr`) AS `qouteDr`,
    sum(`get_profit_loss_expenditure`.`qouteCr`) AS `qouteCr`,
    sum(`get_profit_loss_expenditure`.`cashDr`)  AS `cashDr`,
    sum(`get_profit_loss_expenditure`.`cashCr`)  AS `cashCr`,
    sum(`get_profit_loss_expenditure`.`bankDr`)  AS `bankDr`,
    sum(`get_profit_loss_expenditure`.`bankCr`)  AS `bankCr`,
    `get_profit_loss_expenditure`.`yearID`       AS `yearID`,
    `get_profit_loss_expenditure`.`profitlossID` AS `profitlossID`
  FROM `ghanacu_account`.`get_profit_loss_expenditure`
  GROUP BY `get_profit_loss_expenditure`.`GL_ID`, `get_profit_loss_expenditure`.`tranDate`,
    `get_profit_loss_expenditure`.`GL_date`, `get_profit_loss_expenditure`.`ticketID`,
    `get_profit_loss_expenditure`.`bookID`, `get_profit_loss_expenditure`.`tranCatID`,
    `get_profit_loss_expenditure`.`description`, `get_profit_loss_expenditure`.`refNo`,
    `get_profit_loss_expenditure`.`tranTypeID`, `get_profit_loss_expenditure`.`yearID`,
    `get_profit_loss_expenditure`.`semesterID`, `get_profit_loss_expenditure`.`advance_payID`,
    `get_profit_loss_expenditure`.`staffID`, `get_profit_loss_expenditure`.`profitlossID`,
    `get_profit_loss_expenditure`.`balanceSheetID`, `get_profit_loss_expenditure`.`salaryControlID`,
    `get_profit_loss_expenditure`.`capital`, `get_profit_loss_expenditure`.`drawings`,
    `get_profit_loss_expenditure`.`supplerID`, `get_profit_loss_expenditure`.`userID`;
