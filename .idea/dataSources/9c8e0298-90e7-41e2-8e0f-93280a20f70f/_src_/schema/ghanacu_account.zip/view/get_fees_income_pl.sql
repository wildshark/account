CREATE VIEW get_fees_income_pl AS
  SELECT
    sum(`ghanacu_account`.`fees_revenue`.`amount`) AS `amount`,
    `ghanacu_account`.`fees_revenue`.`payDate`     AS `date`
  FROM `ghanacu_account`.`fees_revenue`
  GROUP BY `ghanacu_account`.`fees_revenue`.`payDate`;
