CREATE VIEW get_total_salary_calculation AS
  SELECT
    sum(`get_payroll`.`basic`)                                                       AS `ToatalBasic`,
    sum(`get_payroll`.`allowance`)                                                   AS `TotalAllowance`,
    sum(`get_payroll`.`ssf`)                                                         AS `ssf`,
    sum((`get_payroll`.`basic` + `get_payroll`.`allowance`))                         AS `NetSalary`,
    sum(((`get_payroll`.`basic` + `get_payroll`.`allowance`) + `get_payroll`.`ssf`)) AS `TotalSalaryCost`,
    `get_payroll`.`year`                                                             AS `year`,
    `get_payroll`.`semester`                                                         AS `semester`,
    `get_payroll`.`payDate`                                                          AS `payDate`
  FROM `ghanacu_account`.`get_payroll`
  GROUP BY `get_payroll`.`year`, `get_payroll`.`semester`, `get_payroll`.`payDate`;
