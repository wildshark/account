CREATE VIEW get_session AS
  SELECT
    `ghanacu_account`.`session`.`yearID` AS `yearID`,
    `ghanacu_account`.`session`.`year`   AS `year`
  FROM `ghanacu_account`.`session`;
