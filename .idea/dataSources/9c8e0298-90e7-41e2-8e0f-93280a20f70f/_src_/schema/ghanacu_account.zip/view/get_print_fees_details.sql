CREATE VIEW get_print_fees_details AS
  SELECT
    `ghanacu_account`.`fees_bill`.`fees_journalID` AS `fees_journalID`,
    `ghanacu_account`.`fees_bill`.`transDate`      AS `transDate`,
    `ghanacu_account`.`fees_bill`.`jDate`          AS `jDate`,
    `ghanacu_account`.`fees_bill`.`yearID`         AS `yearID`,
    `ghanacu_account`.`fees_bill`.`semesterID`     AS `semesterID`,
    `ghanacu_account`.`fees_bill`.`studentID`      AS `studentID`,
    `ghanacu_account`.`fees_bill`.`revenueID`      AS `revenueID`,
    `ghanacu_account`.`fees_bill`.`amount`         AS `amount`,
    `ghanacu_account`.`revenue_list`.`revenue`     AS `revenue`
  FROM (`ghanacu_account`.`fees_bill`
    JOIN `ghanacu_account`.`revenue_list`
      ON ((`ghanacu_account`.`fees_bill`.`revenueID` = `ghanacu_account`.`revenue_list`.`revenueID`)));
