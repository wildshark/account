CREATE VIEW get_advance_payment AS
  SELECT
    `ghanacu_account`.`general_legder`.`bookID`                                                        AS `bookID`,
    `ghanacu_account`.`general_legder`.`tranCatID`                                                     AS `tranCatID`,
    sum(`ghanacu_account`.`general_legder`.`qouteDr`)                                                  AS `cost`,
    sum(`ghanacu_account`.`general_legder`.`qouteCr`)                                                  AS `paid`,
    sum((`ghanacu_account`.`general_legder`.`qouteCr` - `ghanacu_account`.`general_legder`.`qouteDr`)) AS `bal`,
    `ghanacu_account`.`chart_of_account`.`ledger`                                                      AS `ledger`
  FROM (`ghanacu_account`.`general_legder`
    JOIN `ghanacu_account`.`chart_of_account`
      ON ((`ghanacu_account`.`general_legder`.`tranCatID` = `ghanacu_account`.`chart_of_account`.`TranCatID`)))
  GROUP BY `ghanacu_account`.`general_legder`.`bookID`, `ghanacu_account`.`general_legder`.`tranCatID`;
