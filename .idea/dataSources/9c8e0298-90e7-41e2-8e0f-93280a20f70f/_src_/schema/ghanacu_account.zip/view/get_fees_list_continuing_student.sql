CREATE VIEW get_fees_list_continuing_student AS
  SELECT
    `ghanacu_account`.`fees_price_list`.`feesID`                                                    AS `feesID`,
    `ghanacu_account`.`fees_price_list`.`schoolID`                                                  AS `schoolID`,
    `ghanacu_account`.`fees_price_list`.`tuition`                                                   AS `tuition`,
    `ghanacu_account`.`fees_price_list`.`hostel`                                                    AS `hostel`,
    `ghanacu_account`.`fees_price_list`.`src_dues`                                                  AS `src_dues`,
    `ghanacu_account`.`fees_price_list`.`technology`                                                AS `technology`,
    `ghanacu_account`.`fees_price_list`.`other2`                                                    AS `other2`,
    `ghanacu_account`.`fees_price_list`.`other1`                                                    AS `other1`,
    `ghanacu_account`.`fees_price_list`.`statusID`                                                  AS `statusID`,
    (((`ghanacu_account`.`fees_price_list`.`src_dues` + `ghanacu_account`.`fees_price_list`.`technology`) +
      `ghanacu_account`.`fees_price_list`.`other2`) + `ghanacu_account`.`fees_price_list`.`other1`) AS `other_fees`
  FROM `ghanacu_account`.`fees_price_list`;
