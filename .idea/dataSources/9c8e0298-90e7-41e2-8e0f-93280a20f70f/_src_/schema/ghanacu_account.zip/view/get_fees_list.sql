CREATE VIEW get_fees_list AS
  SELECT
    `ghanacu_account`.`fees_price_list`.`feesID`            AS `feesID`,
    `ghanacu_account`.`fees_price_list`.`schoolID`          AS `schoolID`,
    `ghanacu_account`.`fees_price_list`.`tuition`           AS `tuition`,
    ((((((((`ghanacu_account`.`fees_price_list`.`matriculation` + `ghanacu_account`.`fees_price_list`.`accept_fees`) +
           `ghanacu_account`.`fees_price_list`.`medical_examin`) + `ghanacu_account`.`fees_price_list`.`result_fees`) +
         `ghanacu_account`.`fees_price_list`.`lab_fees`) + `ghanacu_account`.`fees_price_list`.`indexing`) +
       `ghanacu_account`.`fees_price_list`.`nmc_book`) + `ghanacu_account`.`fees_price_list`.`clinical_fees`) +
     `ghanacu_account`.`fees_price_list`.`graduation_fees`) AS `other_cost`,
    `ghanacu_account`.`fees_price_list`.`statusID`          AS `statusID`,
    `ghanacu_account`.`school`.`prefix`                     AS `prefix`
  FROM (`ghanacu_account`.`fees_price_list`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`fees_price_list`.`schoolID`)));
