CREATE VIEW get_fees_list AS
  SELECT
    `ghanacu_account`.`fees_price_list`.`feesID`                                                                    AS `feesID`,
    `ghanacu_account`.`fees_price_list`.`schoolID`                                                                  AS `schoolID`,
    `ghanacu_account`.`fees_price_list`.`tuition`                                                                   AS `tuition`,
    `ghanacu_account`.`fees_price_list`.`matriculation`                                                             AS `matriculation`,
    `ghanacu_account`.`fees_price_list`.`accept_fees`                                                               AS `accept_fees`,
    `ghanacu_account`.`fees_price_list`.`medical_examin`                                                            AS `medical_examin`,
    `ghanacu_account`.`fees_price_list`.`result_fees`                                                               AS `result_fees`,
    `ghanacu_account`.`fees_price_list`.`lab_fees`                                                                  AS `lab_fees`,
    `ghanacu_account`.`fees_price_list`.`graduation_fees`                                                           AS `graduation_fees`,
    `ghanacu_account`.`fees_price_list`.`clinical_fees`                                                             AS `clinical_fees`,
    `ghanacu_account`.`fees_price_list`.`nmc_book`                                                                  AS `nmc_book`,
    `ghanacu_account`.`fees_price_list`.`indexing`                                                                  AS `indexing`,
    ((((((((`ghanacu_account`.`fees_price_list`.`matriculation` + `ghanacu_account`.`fees_price_list`.`accept_fees`) +
           `ghanacu_account`.`fees_price_list`.`medical_examin`) + `ghanacu_account`.`fees_price_list`.`result_fees`) +
         `ghanacu_account`.`fees_price_list`.`lab_fees`) + `ghanacu_account`.`fees_price_list`.`indexing`) +
       `ghanacu_account`.`fees_price_list`.`nmc_book`) + `ghanacu_account`.`fees_price_list`.`clinical_fees`) +
     `ghanacu_account`.`fees_price_list`.`graduation_fees`)                                                         AS `other_fees`,
    (((((((((`ghanacu_account`.`fees_price_list`.`tuition` + `ghanacu_account`.`fees_price_list`.`matriculation`) +
            `ghanacu_account`.`fees_price_list`.`accept_fees`) + `ghanacu_account`.`fees_price_list`.`medical_examin`) +
          `ghanacu_account`.`fees_price_list`.`result_fees`) + `ghanacu_account`.`fees_price_list`.`lab_fees`) +
        `ghanacu_account`.`fees_price_list`.`indexing`) + `ghanacu_account`.`fees_price_list`.`nmc_book`) +
      `ghanacu_account`.`fees_price_list`.`clinical_fees`) +
     `ghanacu_account`.`fees_price_list`.`graduation_fees`)                                                         AS `total_fees`,
    `ghanacu_account`.`fees_price_list`.`statusID`                                                                  AS `statusID`,
    `ghanacu_account`.`school`.`prefix`                                                                             AS `prefix`,
    `ghanacu_account`.`school`.`school`                                                                             AS `school`
  FROM (`ghanacu_account`.`fees_price_list`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`school`.`schoolID` = `ghanacu_account`.`fees_price_list`.`schoolID`)));
