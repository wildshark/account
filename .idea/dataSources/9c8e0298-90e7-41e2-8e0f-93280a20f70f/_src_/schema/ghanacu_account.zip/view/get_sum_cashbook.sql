CREATE VIEW get_sum_cashbook AS
  SELECT
    sum(`get_cashbook`.`cashDr`)  AS `Debit`,
    sum(`get_cashbook`.`cashCr`)  AS `Credit`,
    count(`get_cashbook`.`GL_ID`) AS `NoTran`
  FROM `ghanacu_account`.`get_cashbook`;
