CREATE VIEW get_loan_payment AS
  SELECT
    `ghanacu_account`.`loan_details`.`loanID`        AS `loanID`,
    `ghanacu_account`.`loan_details`.`staff_loan_ID` AS `staff_loan_ID`,
    `ghanacu_account`.`loan_details`.`staffID`       AS `staffID`,
    `ghanacu_account`.`loan_details`.`semester`      AS `semester`,
    `ghanacu_account`.`loan_details`.`yearID`        AS `yearID`,
    `ghanacu_account`.`loan_details`.`date`          AS `date`,
    `ghanacu_account`.`loan_details`.`amount`        AS `amount`,
    `ghanacu_account`.`staff_profile`.`staffName`    AS `staffName`
  FROM (`ghanacu_account`.`loan_details`
    JOIN `ghanacu_account`.`staff_profile`
      ON ((`ghanacu_account`.`loan_details`.`staffID` = `ghanacu_account`.`staff_profile`.`staff_profile_ID`)));
