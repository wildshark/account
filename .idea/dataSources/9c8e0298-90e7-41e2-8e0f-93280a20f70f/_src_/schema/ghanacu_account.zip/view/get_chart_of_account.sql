CREATE VIEW get_chart_of_account AS
  SELECT
    `ghanacu_account`.`chart_of_account`.`TranCatID`      AS `TranCatID`,
    `ghanacu_account`.`chart_of_account`.`bookID`         AS `bookID`,
    `ghanacu_account`.`chart_of_account`.`ledger`         AS `ledger`,
    `ghanacu_account`.`chart_of_account`.`profitLossID`   AS `profitLossID`,
    `ghanacu_account`.`chart_of_account`.`balanceSheetID` AS `balanceSheetID`,
    `ghanacu_account`.`chart_of_account`.`statusID`       AS `statusID`
  FROM `ghanacu_account`.`chart_of_account`;
