CREATE VIEW get_user_list AS
  SELECT
    `ghanacu_account`.`user_account`.`userID`     AS `userID`,
    `ghanacu_account`.`user_account`.`full_name`  AS `full_name`,
    `ghanacu_account`.`user_account`.`mobile`     AS `mobile`,
    `ghanacu_account`.`user_account`.`email`      AS `email`,
    `ghanacu_account`.`user_account`.`userName`   AS `userName`,
    `ghanacu_account`.`user_account`.`userPasswd` AS `userPasswd`,
    `ghanacu_account`.`user_account`.`roleID`     AS `roleID`,
    `ghanacu_account`.`user_account`.`statusID`   AS `statusID`
  FROM `ghanacu_account`.`user_account`;
