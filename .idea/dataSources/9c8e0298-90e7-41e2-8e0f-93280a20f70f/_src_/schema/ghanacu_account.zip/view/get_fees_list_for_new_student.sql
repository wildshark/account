CREATE VIEW get_fees_list_for_new_student AS
  SELECT
    `ghanacu_account`.`fees_price_list`.`feesID`         AS `feesID`,
    `ghanacu_account`.`fees_price_list`.`schoolID`       AS `schoolID`,
    `ghanacu_account`.`fees_price_list`.`tuition`        AS `tuition`,
    (((((((((((`ghanacu_account`.`fees_price_list`.`matriculation` + `ghanacu_account`.`fees_price_list`.`accept_fees`)
              + `ghanacu_account`.`fees_price_list`.`medical_examin`) +
             `ghanacu_account`.`fees_price_list`.`result_fees`) + `ghanacu_account`.`fees_price_list`.`indexing`) +
           `ghanacu_account`.`fees_price_list`.`nmc_book`) + `ghanacu_account`.`fees_price_list`.`clinical_fees`) +
         `ghanacu_account`.`fees_price_list`.`technology`) + `ghanacu_account`.`fees_price_list`.`hostel`) +
       `ghanacu_account`.`fees_price_list`.`wasce`) + `ghanacu_account`.`fees_price_list`.`other2`) +
     `ghanacu_account`.`fees_price_list`.`other1`)       AS `other_fees`,
    `ghanacu_account`.`fees_price_list`.`statusID`       AS `statusID`,
    `ghanacu_account`.`school`.`school`                  AS `school`,
    `ghanacu_account`.`school`.`prefix`                  AS `prefix`,
    `ghanacu_account`.`fees_price_list`.`matriculation`  AS `matriculation`,
    `ghanacu_account`.`fees_price_list`.`accept_fees`    AS `accept_fees`,
    `ghanacu_account`.`fees_price_list`.`medical_examin` AS `medical_examin`,
    `ghanacu_account`.`fees_price_list`.`result_fees`    AS `result_fees`,
    `ghanacu_account`.`fees_price_list`.`lab_fees`       AS `lab_fees`,
    `ghanacu_account`.`fees_price_list`.`other1`         AS `other1`,
    `ghanacu_account`.`fees_price_list`.`other2`         AS `other2`,
    `ghanacu_account`.`fees_price_list`.`src_dues`       AS `src_dues`,
    `ghanacu_account`.`fees_price_list`.`wasce`          AS `wasce`,
    `ghanacu_account`.`fees_price_list`.`hostel`         AS `hostel`,
    `ghanacu_account`.`fees_price_list`.`technology`     AS `technology`,
    `ghanacu_account`.`fees_price_list`.`clinical_fees`  AS `clinical_fees`,
    `ghanacu_account`.`fees_price_list`.`nmc_book`       AS `nmc_book`,
    `ghanacu_account`.`fees_price_list`.`indexing`       AS `indexing`
  FROM (`ghanacu_account`.`fees_price_list`
    JOIN `ghanacu_account`.`school`
      ON ((`ghanacu_account`.`fees_price_list`.`schoolID` = `ghanacu_account`.`school`.`schoolID`)));
