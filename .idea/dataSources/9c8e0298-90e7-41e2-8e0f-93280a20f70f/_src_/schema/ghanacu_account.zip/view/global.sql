CREATE VIEW global AS
  SELECT
    `get_expenditure_list`.`TranCatID`      AS `TranCatID`,
    `get_expenditure_list`.`ledger`         AS `ledger`,
    `get_expenditure_list`.`bookID`         AS `bookID`,
    `get_expenditure_list`.`profitLossID`   AS `profitLossID`,
    `get_expenditure_list`.`balanceSheetID` AS `balanceSheetID`,
    `get_expenditure_list`.`statusID`       AS `statusID`
  FROM `ghanacu_account`.`get_expenditure_list`
  WHERE ((`get_expenditure_list`.`TranCatID` <> 39) AND (`get_expenditure_list`.`TranCatID` <> 41) AND
         (`get_expenditure_list`.`TranCatID` <> 34));
