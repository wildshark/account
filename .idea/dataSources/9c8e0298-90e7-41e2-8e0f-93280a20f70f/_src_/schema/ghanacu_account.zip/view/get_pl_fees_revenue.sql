CREATE VIEW get_pl_fees_revenue AS
  SELECT
    `ghanacu_account`.`fees_journal`.`revenueID`   AS `revenueID`,
    sum(`ghanacu_account`.`fees_journal`.`amount`) AS `total`,
    `ghanacu_account`.`fees_journal`.`jDate`       AS `jDate`,
    `ghanacu_account`.`revenue_list`.`revenue`     AS `revenue`
  FROM (`ghanacu_account`.`fees_journal`
    JOIN `ghanacu_account`.`revenue_list`
      ON ((`ghanacu_account`.`fees_journal`.`revenueID` = `ghanacu_account`.`revenue_list`.`revenueID`)))
  GROUP BY `ghanacu_account`.`fees_journal`.`revenueID`, `ghanacu_account`.`fees_journal`.`jDate`
  ORDER BY `ghanacu_account`.`revenue_list`.`revenueID`;
