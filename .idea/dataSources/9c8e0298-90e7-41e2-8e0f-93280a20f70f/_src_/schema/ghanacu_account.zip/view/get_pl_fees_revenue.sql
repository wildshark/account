CREATE VIEW get_pl_fees_revenue AS
  SELECT
    `ghanacu_account`.`fees_bill`.`revenueID`   AS `revenueID`,
    sum(`ghanacu_account`.`fees_bill`.`amount`) AS `total`,
    `ghanacu_account`.`fees_bill`.`jDate`       AS `jDate`,
    `ghanacu_account`.`revenue_list`.`revenue`  AS `revenue`
  FROM (`ghanacu_account`.`fees_bill`
    JOIN `ghanacu_account`.`revenue_list`
      ON ((`ghanacu_account`.`fees_bill`.`revenueID` = `ghanacu_account`.`revenue_list`.`revenueID`)))
  GROUP BY `ghanacu_account`.`fees_bill`.`revenueID`, `ghanacu_account`.`fees_bill`.`jDate`
  ORDER BY `ghanacu_account`.`revenue_list`.`revenueID`;
