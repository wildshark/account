CREATE VIEW expenses_pay_list AS
  SELECT
    `get_expenses_payment_list`.`tranCatID`       AS `tranCatID`,
    `get_expenses_payment_list`.`Qoute`           AS `Qoute`,
    `get_expenses_payment_list`.`Paid`            AS `Paid`,
    `get_expenses_payment_list`.`bal`             AS `bal`,
    `ghanacu_account`.`chart_of_account`.`ledger` AS `ledger`,
    `get_expenses_payment_list`.`bookID`          AS `bookID`
  FROM (`ghanacu_account`.`get_expenses_payment_list`
    JOIN `ghanacu_account`.`chart_of_account`
      ON ((`get_expenses_payment_list`.`tranCatID` = `ghanacu_account`.`chart_of_account`.`TranCatID`)))
  WHERE ((`get_expenses_payment_list`.`bal` > 0) AND (`get_expenses_payment_list`.`bookID` = 2));
