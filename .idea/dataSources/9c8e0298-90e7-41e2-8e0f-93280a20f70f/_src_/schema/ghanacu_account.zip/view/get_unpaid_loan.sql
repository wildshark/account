CREATE VIEW get_unpaid_loan AS
  SELECT
    `ghanacu_account`.`staff_loan`.`staff_loan_ID` AS `staff_loan_ID`,
    `ghanacu_account`.`staff_loan`.`tranDate`      AS `tranDate`,
    `ghanacu_account`.`staff_loan`.`loanDate`      AS `loanDate`,
    `ghanacu_account`.`staff_loan`.`staffID`       AS `staffID`,
    `ghanacu_account`.`staff_loan`.`detail`        AS `detail`,
    `ghanacu_account`.`staff_loan`.`pay_amount`    AS `pay_amount`,
    `ghanacu_account`.`staff_loan`.`loan`          AS `loan`,
    `ghanacu_account`.`staff_loan`.`statusID`      AS `statusID`,
    `ghanacu_account`.`loan_details`.`loanID`      AS `loanID`,
    sum(`ghanacu_account`.`loan_details`.`amount`) AS `paid`
  FROM (`ghanacu_account`.`staff_loan`
    JOIN `ghanacu_account`.`loan_details`
      ON ((`ghanacu_account`.`loan_details`.`staff_loan_ID` = `ghanacu_account`.`staff_loan`.`staff_loan_ID`)))
  WHERE (`ghanacu_account`.`staff_loan`.`statusID` = 1)
  GROUP BY `ghanacu_account`.`staff_loan`.`staff_loan_ID`, `ghanacu_account`.`staff_loan`.`tranDate`,
    `ghanacu_account`.`staff_loan`.`loanDate`, `ghanacu_account`.`staff_loan`.`staffID`,
    `ghanacu_account`.`staff_loan`.`detail`, `ghanacu_account`.`staff_loan`.`pay_amount`,
    `ghanacu_account`.`staff_loan`.`loan`, `ghanacu_account`.`staff_loan`.`statusID`,
    `ghanacu_account`.`loan_details`.`loanID`;
