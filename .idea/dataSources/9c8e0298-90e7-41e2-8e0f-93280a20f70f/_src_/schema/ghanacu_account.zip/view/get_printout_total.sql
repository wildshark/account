CREATE VIEW get_printout_total AS
  SELECT
    `get_print_fees_details`.`yearID`      AS `yearID`,
    `get_print_fees_details`.`semesterID`  AS `semesterID`,
    `get_print_fees_details`.`studentID`   AS `studentID`,
    sum(`get_print_fees_details`.`amount`) AS `total`
  FROM `ghanacu_account`.`get_print_fees_details`
  GROUP BY `get_print_fees_details`.`yearID`, `get_print_fees_details`.`semesterID`,
    `get_print_fees_details`.`studentID`;
