CREATE VIEW get_staff_loan AS
  SELECT
    `ghanacu_account`.`staff_loan`.`staff_loan_ID`  AS `staff_loan_ID`,
    `ghanacu_account`.`staff_loan`.`tranDate`       AS `tranDate`,
    `ghanacu_account`.`staff_loan`.`loanDate`       AS `loanDate`,
    `ghanacu_account`.`staff_loan`.`staffID`        AS `staffID`,
    `ghanacu_account`.`staff_loan`.`detail`         AS `detail`,
    `ghanacu_account`.`staff_loan`.`yearID`         AS `yearID`,
    `ghanacu_account`.`staff_loan`.`semester`       AS `semester`,
    `ghanacu_account`.`staff_loan`.`pay_amount`     AS `pay_amount`,
    `ghanacu_account`.`staff_loan`.`loan`           AS `loan`,
    `ghanacu_account`.`staff_loan`.`paidDateUpdate` AS `paidDateUpdate`,
    `ghanacu_account`.`staff_loan`.`paid`           AS `paid`,
    `ghanacu_account`.`staff_loan`.`statusID`       AS `statusID`
  FROM `ghanacu_account`.`staff_loan`;
