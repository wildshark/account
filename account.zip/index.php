<?php
/**
 * Created by PhpStorm.
 * User: Andrew Quaye
 * Date: 29-Jun-17
 * Time: 12:40 PM
 */

include_once "config/config.php";
include_once "template/login.php";
