<?php
/**
 * Created by PhpStorm.
 * User: Andrew Quaye
 * Date: 06-Jul-17
 * Time: 10:17 AM
 */

function revenue($conn){

}

function expenses($conn){

}
