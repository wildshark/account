<?php
/**
 * Created by PhpStorm.
 * User: Andrew Quaye
 * Date: 29-Jun-17
 * Time: 12:46 PM
 */

?>
<title><?php echo $page->header;?></title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="template/css/bootstrap.min.css" />
<link rel="stylesheet" href="template/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="template/css/fullcalendar.css" />
<link rel="stylesheet" href="template/css/maruti-style.css" />
<link rel="stylesheet" href="template/css/maruti-media.css" class="skin-color" />